const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

https://api.openai.com/v1/chat/completions
    const userMessage = req.body.message;
    console.log("Mensagem do usuário:", userMessage); // Log da mensagem do usuário

    try {
        const response = await axios.post('https://api.openai.com/v1/chat/completions', {
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: userMessage }],
        }, {
            headers: {
                'Authorization': `#`, // Substitua pelo seu token de API
                'Content-Type': 'application/json'
            }
        });

        const aiResponse = response.data.choices[0].message.content;
        console.log("Resposta da IA:", aiResponse); // Log da resposta da IA
        res.json({ response: aiResponse });
    } catch (error) {
        console.error("Erro ao se comunicar com a IA:", error); // Log do erro
        res.status(500).send('Erro ao se comunicar com a IA');
    }
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});